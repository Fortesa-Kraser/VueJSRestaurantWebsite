<h1>VueJS-RestaurantWebsite | A simple restaurant website using VUE JS</h1>
<hr>
<h3>Technologies: HTML, CSS and Vue JS</h3>
<img src = "restaurant_vuejs.png" alt = "Homepage">
